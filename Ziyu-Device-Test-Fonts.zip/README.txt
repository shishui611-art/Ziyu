洛书字体组合测试字体

解压后将三个 TTF 分别导入字体库并指定角色：
- 中文：fonts/中文/NotoSansSC-Test-VF.ttf
- 英文：fonts/英文/Roboto-VF.ttf
- 数字：fonts/数字/RobotoMono-VF.ttf

三款字体均为可变字重（wght 100–900）。我已按洛书兼容引擎逐档处理三个来源并生成九档复合字体，全部通过字体结构和覆盖校验。中文测试字体是 Noto Sans SC 的约 3,600 字形测试子集，适合验证组合和预览，不建议作日常系统字体。

字体来自 Google Fonts，采用 SIL Open Font License 1.1；授权文本在 licenses/ 中。源文件：
- https://github.com/google/fonts/tree/main/ofl/notosanssc
- https://github.com/google/fonts/tree/main/ofl/roboto
- https://github.com/google/fonts/tree/main/ofl/robotomono

把三个字体导入软件后，按中文、英文、数字角色分别选择，再执行字体组合。
